# Hackbar-2.3.1
Firefox and Chorme Hackbar 2.3.1

### 安装方法：
1、Firefox：hackbar-2.3.1-fx.xpi拖拽到浏览器内即可。

2、Chrome：HackBar 2.3.1.zip解压后使用开发者模式导入。
